from .TCPserver import TCPMultiplayerServer
from .client import MultiplayerClient
from .server_manager import ServerManager
from .functions import get_servers, create_server, get_player_count_of_server
print("pymultiplayer by iamdeedz")
print("https://www.github.com/iamdeedz/pymultiplayer")
print("This library is currently a work in progress.")
