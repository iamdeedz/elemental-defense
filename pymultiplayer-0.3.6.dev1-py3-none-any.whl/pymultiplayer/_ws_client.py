class _Client:
    def __init__(self, ws, id):
        self.ws = ws
        self.id = id
